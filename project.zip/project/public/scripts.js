
async function fetchDJs() {
    const response = await fetch('/djs');
    const djs = await response.json();

    const container = document.querySelector('.btns2');
    container.innerHTML = ''; // Clears previous content

    djs.forEach(dj => {
        // Create container for each DJ with their schedules
        let djContainer = document.createElement('div');
        djContainer.classList.add(`button-container_${dj.style}`);

        let djButton = document.createElement('input');
        djButton.type = 'button';
        djButton.value = dj.name;
        djButton.classList.add('btn2page');

        let djHeading = document.createElement('h2');
        djHeading.textContent = dj.name;

        let djDescription = document.createElement('p');
        djDescription.textContent = dj.description;

        djContainer.appendChild(djButton);
        djContainer.appendChild(djHeading);
        djContainer.appendChild(djDescription);

        // Display available schedules
        let scheduleContainer = document.createElement('div');
        scheduleContainer.classList.add('schedule-container');

        dj.schedules.forEach(schedule => {
            if (schedule.isAvailable) {
                let scheduleButton = document.createElement('button');
                scheduleButton.textContent = `${schedule.time} on ${schedule.date}`;
                scheduleButton.classList.add('schedule-btn');
                scheduleButton.addEventListener('click', function() {
                    // Process the schedule selection
                    console.log(`Selected schedule for ${dj.name}: ${schedule.date} at ${schedule.time}`);
                    selectSchedule(dj._id, schedule.date, schedule.time, scheduleButton);
                });

                scheduleContainer.appendChild(scheduleButton);
            }
        });

        djContainer.appendChild(scheduleContainer);
        container.appendChild(djContainer);
    });
}

async function selectSchedule(djId, date, time, button) {
    try {
        const response = await fetch('/select-schedule', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                djId: djId,
                date: date,
                time: time
            })
        });

        const data = await response.json();

        if (response.ok) {
            button.disabled = true;
            button.style.backgroundColor = 'grey';
            button.textContent = 'Booked';

            alert('Your schedule has been saved!');
        } else {
            alert(data.message || 'An error occurred while saving your schedule.');
        }
    } catch (err) {
        console.error('Error selecting schedule:', err);
        alert('An error occurred while selecting the schedule.');
    }
}

fetchDJs();
