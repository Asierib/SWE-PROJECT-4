const express = require('express');
const mongoose = require('mongoose');
const expressLayouts = require('express-ejs-layouts');
const session = require('express-session');  
const indexRoutes = require('./routes/index'); 
const scheduleRoutes = require('./routes/schedule'); 
const DJ = require('./models/dj');  
const Song = require('./models/song'); 

const app = express();


app.use(session({
  secret: 'your-secret-key', 
  resave: false, 
  saveUninitialized: true, 
  cookie: { secure: false } 
}));

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/radioApp', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("Connected to MongoDB");
  seedDatabase(); 
}).catch((err) => {
  console.error("Error connecting to MongoDB", err);
});

async function seedDatabase() {
  const djData = [
    {
      name: "DJ BLAZE",
      description: "Fuses electronic beats with jazz melodies",
      image: "dj1.jpg",
      schedules: [
        { date: "2024-12-01", time: "20:00-22:00", isAvailable: true }
      ]
    },
    {
      name: "DJ TOTOTE",
      description: "Hypnotic beats and ethereal sounds",
      image: "dj2.jpg",
      schedules: []
    },
    {
      name: "DJ LUNA",
      description: "Master of techno, transforming any dance floor into an unforgettable, energetic party.",
      image: "dj3.jpg",
      schedules: []
    },
    {
      name: "DJ MAGNO",
      description: "Remix specialist, blending genres to make crowds vibrate with excitement.",
      image: "dj4.jpg",
      schedules: [
        { date: "2024-12-01", time: "22:00-24:00", isAvailable: false },
        { date: "2024-12-02", time: "20:00-22:00", isAvailable: false },
        { date: "2024-12-03", time: "22:00-24:00", isAvailable: false }
      ]
    }
  ];

  for (const dj of djData) {
    const existingDJ = await DJ.findOne({ name: dj.name });
    if (!existingDJ) {
      await DJ.create(dj);
      console.log(`${dj.name} seeded successfully!`);
    } else {
      console.log(`${dj.name} already exists!`);
    }
  }

  const songData = [
    { song: "Despacito", artist: "Bad Bunny", year: 2017, played: "yes" },
    { song: "Taki Taki", artist: "JCal", year: 2018, played: "no" },
    { song: "Baila Baila Baila", artist: "J Balvin", year: 2019, played: "yes" },
    { song: "Vibe With Me", artist: "Bad Bunny", year: 2021, played: "no" },
    { song: "Fire Dance", artist: "Ozuna", year: 2020, played: "yes" },
    { song: "Stay Close", artist: "Anuel", year: 2019, played: "no" },
    { song: "Eclipse", artist: "J Balvin", year: 2022, played: "yes" },
    { song: "Luna", artist: "Bad Bunny", year: 2020, played: "no" },
    { song: "Sombra", artist: "JCal", year: 2021, played: "yes" },
  ];

  try {
    await Song.insertMany(songData);
    console.log('Songs seeded successfully!');
  } catch (err) {
    console.log('Error seeding songs:', err);
  }
}

app.set('view engine', 'ejs');
app.use(expressLayouts);
app.set('layout', 'layouts/main');

app.use(express.static('public'));

app.use('/', indexRoutes);
app.use('/schedule', scheduleRoutes);

app.get('/', (req, res) => {
  res.render('pages/index');
});

app.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).send('Failed to log out');
    }
    res.send({ message: 'Logged out successfully' });
  });
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
