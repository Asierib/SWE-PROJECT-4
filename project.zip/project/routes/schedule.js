const express = require('express');
const DJ = require('../models/dj');
const router = express.Router();

router.get('/:name', async (req, res) => {
  const dj = await DJ.findOne({ name: req.params.name });
  res.render('pages/schedule', { dj, title: `Schedule for ${dj.name}` });
});


module.exports = router;
