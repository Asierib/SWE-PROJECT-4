const express = require('express');
const DJ = require('../models/dj');
const router = express.Router();

router.get('/', async (req, res) => {
    try {
        const djs = await DJ.find();  
        res.render('pages/index', { 
            djs, 
            title: 'My Radio Web'
        });
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.get('/djs', async (req, res) => {
    try {
        const djs = await DJ.find();
        res.json(djs);
    } catch (err) {
        res.status(500).send(err.message);
    }
});

router.post('/select-schedule', async (req, res) => {
  try {
    const { djId, date, time } = req.body;

    const dj = await DJ.findById(djId);
    if (!dj) {
      return res.status(404).send('DJ not found');
    }

    const existingSchedule = dj.schedules.find(schedule => schedule.date === date && schedule.time === time);
    if (existingSchedule && !existingSchedule.isAvailable) {
      return res.status(400).send('This time slot is already taken');
    }

    const newSchedule = { date, time, isAvailable: false };  
    dj.schedules.push(newSchedule);  
    console.log("New schedule added:", newSchedule);  

    await dj.save();  

    res.status(200).send('Schedule added successfully');
  } catch (err) {
    res.status(500).send(err.message);
  }
});


module.exports = router;
