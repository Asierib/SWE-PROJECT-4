const mongoose = require('mongoose');

const DJSchema = new mongoose.Schema({
    name: { type: String, required: true },
    description: { type: String, required: true },
    image: { type: String },
    schedules: [
        {
            date: { type: String },
            time: { type: String },
            isAvailable: { type: Boolean, default: true },
        },
    ],
});

module.exports = mongoose.model('DJ', DJSchema);

