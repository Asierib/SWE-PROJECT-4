const mongoose = require('mongoose');
const DJ = require('./models/dj');  
const Song = require('./models/song'); 


mongoose.connect('mongodb://localhost:27017/radioApp', {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log("Connected to MongoDB");

  
  const songData = [
    { song: "Despacito", artist: "Bad Bunny", year: 2017, played: "yes" },
    { song: "Taki Taki", artist: "JCal", year: 2018, played: "no" },
    { song: "Baila Baila Baila", artist: "J Balvin", year: 2019, played: "yes" },
    { song: "Vibe With Me", artist: "Bad Bunny", year: 2021, played: "no" },
    { song: "Fire Dance", artist: "Ozuna", year: 2020, played: "yes" },
    { song: "Stay Close", artist: "Anuel", year: 2019, played: "no" },
    { song: "Eclipse", artist: "J Balvin", year: 2022, played: "yes" },
    { song: "Luna", artist: "Bad Bunny", year: 2020, played: "no" },
    { song: "Sombra", artist: "JCal", year: 2021, played: "yes" },
    
  ];


  Song.insertMany(songData)
    .then(() => {
      console.log('Songs seeded successfully!');
    })
    .catch(err => {
      console.log('Error seeding songs:', err);
    });

}).catch(err => {
  console.log('Error connecting to MongoDB', err);
});
